# Multimodal-system-for-integrated-image-and-audio-analysis-and-narration_TAE_IA
This repository corresponds to the final project of module 6 of the advanced automation and engineering (TAE) course in artificial intelligence.
