"""Utilidades compartidas por MediaScope."""
